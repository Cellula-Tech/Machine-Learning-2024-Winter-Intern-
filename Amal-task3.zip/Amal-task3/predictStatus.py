

def predictStatus(lead_time, special_requests,average_price ,market_Online,market_Corporate,repeated):

    import joblib

    # Load the pre-trained model
    model = joblib.load('knn.pkl')

    X_test_sample = [[lead_time, special_requests,average_price ,market_Online,market_Corporate,repeated]]  
    Y_predicted = model.predict(X_test_sample)

    return Y_predicted