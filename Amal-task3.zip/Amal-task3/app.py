from waitress import serve
import joblib
from predictStatus import predictStatus
from flask import Flask, render_template, request, jsonify 

app = Flask(__name__)

@app.route('/api/Booking/Status', methods=['GET'])
def Booking_Status_get():
    # Jinja2 template engine is used to render HTML page
    return render_template('form.html')

@app.route('/api/Booking/Status', methods=['POST'])
def BookingStatus_api():
    try:
    
        prediction=predictStatus(request.json['lead_time'],
                                request.json['special_requests'],
                                request.json['average_price'],
                                request.json['market_Online'],
                                request.json['market_Corporate'],
                                request.json['repeated']).item()
        
        booking_status = 'Not Cancelled' if prediction == 1 else 'Cenceled'
        
        return jsonify({"Booking Status": booking_status})
        
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500
    
    return render_template ('form.html', Booking_status='BookingStatus',lead_time=request.form['lead_time']
                           ,special_requests=request.form['special_requests'],
                           average_price=request.form['average_price'],
                           market_Online=request.form['market_Online'],
                           market_Corporate=request.form['market_Corporate'],
                           repeated=request.form['repeated'])



if __name__ == "__main__":
    app.run(debug=True)